import numpy as np
import csv

file_name_pre = "pre-novelty_fence_medium_2021-02-20-17-45-46.csv"
file_name_post = "post-novelty_fence_medium_2021-02-20-17-45-46.csv"
pre = []
pre_steps = []
with open(file_name_pre, mode='r') as infile:
    reader = csv.reader(infile)
    next(reader)
    print (reader)
    for line in reader:
        if line[0] != 'Average: ':
            print (line)
            score_pre = float(line[4])
            steps = float(line[1])
            pre.append(score_pre)
            pre_steps.append(steps)
post = []
post_steps = []
with open(file_name_post, mode='r') as infile:
    reader = csv.reader(infile)
    next(reader)
    for line in reader:
        if line[0] != 'Average: ':
            print (line)
            score_post = float(line[4])
            steps = float(line[1])
            post.append(score_post)
            post_steps.append(steps)
post = np.array(post)
pre = np.array(pre)

ratio = post/pre
mean = np.mean(ratio)
std = np.std(ratio)

step_pre_mean = np.mean(pre_steps)
step_pre_std = np.std(pre_steps)
step_post_mean = np.mean(post_steps)
step_post_std = np.std(post_steps)
print (file_name_pre)
print (file_name_post)
print ("Ratio = {} +- {}".format(mean, std))
print ("Steps_pre = {} +- {}".format(step_pre_mean, step_pre_std))
print ("Steps_post = {} +- {}".format(step_post_mean, step_post_std))



